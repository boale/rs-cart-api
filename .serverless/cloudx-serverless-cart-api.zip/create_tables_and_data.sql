CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS carts (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID DEFAULT uuid_generate_v4(),
    created_at DATE NOT NULL,
    updated_at DATE NOT NULL,
    status VARCHAR(8) CHECK (status IN ('OPEN', 'ORDERED')) NOT NULL
);

CREATE TABLE IF NOT EXISTS cart_items (
    cart_id UUID REFERENCES carts(id),
    product_id UUID DEFAULT uuid_generate_v4(),
    count INTEGER,
    PRIMARY KEY (cart_id, product_id)
);

INSERT INTO carts (created_at, updated_at, status)
VALUES
    ('2023-01-01', '2023-01-01', 'OPEN'),
    ('2023-01-02', '2023-01-02', 'ORDERED');

INSERT INTO cart_items (cart_id, count)
VALUES
    ((SELECT id FROM carts WHERE created_at = '2023-01-01'), 3),
    ((SELECT id FROM carts WHERE created_at = '2023-01-01'), 2),
    ((SELECT id FROM carts WHERE created_at = '2023-01-02'), 1);
